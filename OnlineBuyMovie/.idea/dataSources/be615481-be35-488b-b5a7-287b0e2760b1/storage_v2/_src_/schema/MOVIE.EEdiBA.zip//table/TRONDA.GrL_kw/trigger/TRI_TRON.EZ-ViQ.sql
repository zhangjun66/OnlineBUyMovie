create trigger TRI_TRON
  before insert
  on TRONDA
  for each row
  declare
  nextid number;
begin
  IF :new.AID IS NULL or :new.AID=0 THEN
    select SEQ_RON.nextval
    into nextid
    from sys.dual;
    :new.AID:=nextid;
  end if;
end tri_tron;
/

