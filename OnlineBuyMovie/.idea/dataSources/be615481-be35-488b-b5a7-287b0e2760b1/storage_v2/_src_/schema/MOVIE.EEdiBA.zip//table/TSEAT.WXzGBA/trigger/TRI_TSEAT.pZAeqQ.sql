create trigger TRI_TSEAT
  before insert
  on TSEAT
  for each row
  declare
  nextid number;
begin
  IF :new.xho IS NULL or :new.xho=0 THEN
    select SEQ_TSEAT.nextval
    into nextid
    from sys.dual;
    :new.xho:=nextid;
  end if;
end tri_tfilm;
/

