create trigger TRI_TRONDASEAT
  before insert
  on TRONDASEAT
  for each row
  declare
  nextid number;
begin
  IF :new.rsid IS NULL or :new.rsid=0 THEN
    select SEQ_TSID.nextval
    into nextid
    from sys.dual;
    :new.rsid:=nextid;
  end if;
end tri_tfilm;
/

