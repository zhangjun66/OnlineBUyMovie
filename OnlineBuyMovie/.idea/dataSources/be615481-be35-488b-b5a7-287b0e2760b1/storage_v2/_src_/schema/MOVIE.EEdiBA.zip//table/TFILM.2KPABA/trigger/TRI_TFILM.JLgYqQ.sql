create trigger TRI_TFILM
  before insert
  on TFILM
  for each row
  declare
  nextid number;
begin
  IF :new.AID IS NULL or :new.AID=0 THEN
    select SEQ_TID.nextval
    into nextid
    from sys.dual;
    :new.AID:=nextid;
  end if;
end tri_tfilm;
/

